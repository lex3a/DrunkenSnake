const canvas = document.createElement("canvas");
document.body.appendChild(canvas);
canvas.style = "border: 3px solid black";
canvas.width = 800;
canvas.height = 600;
const ctx = canvas.getContext("2d");
const snakeHead = new Image();
const beer = new Image();
beer.src = "./beer.png";
snakeHead.src = "./head.png";
var context = new AudioContext();

function playSound(frequency, type) {
  o = context.createOscillator();
  g = context.createGain();
  o.type = type;
  o.connect(g);
  o.frequency.value = frequency;
  g.connect(context.destination);
  o.start(0);
  g.gain.exponentialRampToValueAtTime(0.00001, context.currentTime + 1);
}

function random(min, max) {
  return Math.floor(Math.random() * (max - min + 1) + min);
}

class Snake {
  constructor(x = 0, y = 0) {
    this.x = x;
    this.y = y;
    this.direction = "bottom";
    this.width = 10;
    this.score = 0;
    this.height = 10;
    this.fpsInterval = 5;
    this.snake = [
      { x: 200, y: 50 },
      { x: 190, y: 50 },
      { x: 180, y: 50 },
      { x: 170, y: 50 },
    ];
    this.food = [];
  }

  logKey(e) {
    switch (e.code) {
      case "ArrowUp":
        if (this.direction === "bottom") return;
        this.direction = "top";
        break;
      case "ArrowDown":
        if (this.direction === "top") return;
        this.direction = "bottom";
        break;
      case "ArrowLeft":
        if (this.direction === "right") return;
        this.direction = "left";
        break;
      case "ArrowRight":
        if (this.direction === "left") return;
        this.direction = "right";
        break;
      default:
        console.log("No direction");
        break;
    }
  }

  generateFood() {
    if (!this.food[0] && !this.food[1]) {
      this.food[0] = random(1, canvas.width - 1);
      this.food[1] = random(1, canvas.height - 1);
    }
  }

  eatFood() {
    if (this.foodCollision()) {
      playSound(830.6, "sine");
      this.food[0] = null;
      this.food[1] = null;
      this.snake.push({ x: this.x + 10, y: 0 });
      this.fpsInterval += 2;
      this.score++;
      console.log(this.tail);
    }
  }

  drawFood() {
    ctx.fillStyle = "red";
    ctx.drawImage(
      beer,
      0,
      0,
      10,
      10,
      this.food[0],
      this.food[1],
      this.width,
      this.height
    );
  }

  foodCollision() {
    if (
      ((this.snake[0].x >= this.food[0] &&
        this.snake[0].x <= this.food[0] + this.width) ||
        (this.snake[0].x + this.width >= this.food[0] &&
          this.snake[0].x + this.width <= this.food[0] + this.width)) &&
      ((this.snake[0].y >= this.food[1] &&
        this.snake[0].y <= this.food[1] + this.height) ||
        (this.snake[0].y + this.height >= this.food[1] &&
          this.snake[0].y + this.height <= this.food[1] + this.height))
    ) {
      console.log(
        "X:",
        this.snake[0].x,
        this.food[0],
        this.food[0] + this.width
      );
      console.log(
        "Y: ",
        this.snake[0].y,
        this.food[1],
        this.food[1] + this.width
      );
      return 1;
    }
    return 0;
  }

  bodyCollision() {
    for (let i = 0; i < this.tail.length; i++) {
      if (
        ((this.head.x >= this.tail[i].x &&
          this.head.x <= this.tail[i].x + this.width) ||
          (this.head.x + this.width >= this.tail[i].x &&
            this.head.x + this.width <= this.tail[i].x + this.width)) &&
        ((this.head.y >= this.tail[i].y &&
          this.head.y <= this.tail[i].y + this.height) ||
          (this.head.y + this.height >= this.tail[i].y &&
            this.head.y + this.height <= this.tail[i].y + this.height))
      ) {
        console.log(
          "X:",
          this.head.x,
          this.tail[i].x,
          this.tail[i].x + this.width
        );
        console.log(
          "Y: ",
          this.head.y,
          this.tail[i].y,
          this.tail[i].y + this.width
        );
        return 1;
      }
    }

    return 0;
  }

  drawSnake() {
    ctx.drawImage(
      snakeHead,
      0,
      0,
      10,
      10,
      this.snake[0].x,
      this.snake[0].y,
      this.width,
      this.height
    );
    ctx.fillStyle = "green";
    for (let i = 1; i < this.snake.length; i++) {
      ctx.fillRect(this.snake[i].x, this.snake[i].y, this.width, this.height);
    }
  }

  move() {
    const head = { x: this.snake[0].x, y: this.snake[0].y };
    switch (this.direction) {
      case "bottom":
        head.y += 10;
        break;
      case "right":
        head.x += 10;
        break;
      case "left":
        head.x -= 10;
        break;
      case "top":
        head.y -= 10;
        break;
    }
    this.snake.unshift(head);
    this.snake.pop();
  }

  isSnakeOutsideCanvas() {
    if (this.snake[0].x >= canvas.width) {
      this.snake[0].x = 0;
    } else if (this.snake[0].x < 0) {
      this.snake[0].x = canvas.width - 1;
    } else if (this.snake[0].y >= canvas.height) {
      this.snake[0].y = 0;
    } else if (this.snake[0].y < 0) {
      this.snake[0].y = canvas.height;
    }
  }

  isGameOver() {
    for (let i = 4; i < this.snake.length; i++) {
      const hasCollided =
        this.snake[i].x === this.snake[0].x &&
        this.snake[i].y === this.snake[0].y;
      if (hasCollided) return true;
    }
  }

  drawScore() {
    ctx.font = "18px serif";
    ctx.fillText(`Score: ${this.score}`, 700, 20);
  }

  drawGameOver() {
    ctx.font = "48px serif";
    ctx.fillText(`Game Over!`, canvas.width / 2 - 96, canvas.height / 2);
    ctx.fillText(
      `Score: ${this.score}`,
      canvas.width / 2 - 48,
      canvas.height / 2 - 48
    );
  }

  update() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (!this.isGameOver()) {
      this.drawScore();
      this.isSnakeOutsideCanvas();
      this.eatFood();
      this.generateFood();
      this.drawFood();
      this.move();
      this.drawSnake();
      setTimeout(
        () => requestAnimationFrame(() => this.update()),
        1000 / this.fpsInterval
      );
    } else {
      this.drawGameOver();
    }
  }
}

let snake = new Snake();

document.addEventListener("keydown", snake.logKey.bind(snake));

snake.update();
